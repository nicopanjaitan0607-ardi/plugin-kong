local plugin = {
  PRIORITY = 10,
  VERSION = "0.1"
}

function plugin:access(conf)
  local minVersion
  local version
  if channel == "WEB" then
    minVersion = conf.web_min_version
    version = ngx.req.get_headers()["mytelkomsel-web-app-version"]
  else
    minVersion = conf.mobile_min_version
    version = ngx.req.get_headers()["mytelkomsel-mobile-app-version"]
  end 

  if version == nil then
    kong.log.err("Invalid App Version")
    return kong.response.exit(403, {message = "Forbidden"})
  end

  if minVersion ~= nil then
    local diff = compareVersion(version, minVersion)
    if (diff < 0) then
      kong.log.err("App Version: " .. version .. ", Min Version: " .. minVersion)
      return kong.response.exit(403, {message = "Unsupported App Version"})
    end
  end

end

function compareVersion(ver1, ver2)
  local v1 = Split(ver1)
  local v2 = Split(ver2)
  for i = 1,3 do
    local z = compareStr(v1[i], v2[i])
    if (z ~= 0 or i == 3) then
      return z
    end
  end
end

function compareStr(s1, s2)
  if tonumber(s1) < tonumber(s2) then
    return -1
  elseif tonumber(s1) > tonumber(s2) then
    return 1
  else
    return 0        
  end 
end

function Split(s)
  local result = {}
  for match in s:gsub("%f[.]%.%f[^.]", "\0"):gmatch"%Z+" do
      table.insert(result, match)
  end
  return result
end

return plugin

