return {
  no_consumer = true,
  fields = {
    mobile_min_version = {type = "string", required = true},
    web_min_version = {type = "string"}
  }
}

