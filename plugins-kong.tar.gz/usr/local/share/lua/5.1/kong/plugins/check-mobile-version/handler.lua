local plugin = {
  PRIORITY = 1000,
  VERSION = "0.1"
}

function plugin:access(conf)
  local channel = ngx.req.get_headers()["channelid"]
  local version = ngx.req.get_headers()["mytelkomsel-mobile-app-version"]
  local path = kong.request.get_path()

  path = path:gsub("/services/api/", "")
  path = path:gsub("/api/", "")

  local skipped_api = conf.skipped_api
  if skipped_api ~= nil then
    for i = 1, #skipped_api do
      if startswith(path, skipped_api[i]) or startswith(path, "/" .. skipped_api[i]) then
        return true
      end
    end
  end

  if channel == nil then
    return kong.response.exit(403, {message = "Forbidden"})
  end

  if channel == "UX" then

    local allowed_version = conf.allowed_version
    for i = 1, #allowed_version do
      if version == allowed_version[i] then
        return true
      end
    end

    return kong.response.exit(403, {message = "Forbidden"})
  end

end

function startswith(text, prefix)
  return text:find(prefix, 1, true) == 1
end

return plugin
