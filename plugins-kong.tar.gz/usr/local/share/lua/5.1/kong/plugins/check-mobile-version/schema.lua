return {
  no_consumer = true,
  fields = {
    skipped_api = {type = "array"},
    allowed_version = {type = "array", required = true}
  }
}
