local sha256 = require "resty.sha256"
local sha224 = require "resty.sha224"
local str = require "resty.string"

local plugin = {
  PRIORITY = 10,
  VERSION = "0.1"
}

function plugin:access(conf)
  local path = kong.request.get_path()

  if conf.path_prefix ~= nil then
    local path_prefix = conf.path_prefix
    for i = 1, #path_prefix do
      if startswith(path, "/" .. path_prefix[i]) then
        path = path:sub(string.len(path_prefix[i]) + 2)
        break
      end
    end
  end

  path = path:gsub("/services/api/", "")
  path = path:gsub("/api/", "")

  -- Check Skipped API
  local skipped_api = conf.skipped_api
  if skipped_api ~= nil and path ~= nil then
    for i = 1, #skipped_api do
      if startswith(path, skipped_api[i]) or startswith(path, "/" .. skipped_api[i]) then
        return true
      end
    end
  end

  local trxId = ngx.req.get_headers()["transactionid"]
  local channel = ngx.req.get_headers()["channelid"]
  local client_hash = ngx.req.get_headers()["hash"]

  if trxId == nil or channel == nil or client_hash == nil then
    return kong.response.exit(403, {message = "Forbidden"})
  end

  if channel == "WEB" then
    local minVersion = conf.web_min_version
    local version = ngx.req.get_headers()["mytelkomsel-web-app-version"]

    if version == nil then
      return kong.response.exit(403, {message = "Forbidden"})
    end

    local compared = compareVersion(version, minVersion)
    if compared >= 0 and conf.web_enable then
      local key = conf.web_hash_key
      local unhashed = trxId .. key .. path .. version
      local digest = sha224:new()
      digest:update(unhashed)
      local digest_created = str.to_hex(digest:final())
      if client_hash ~= digest_created then
        kong.log.err("unhashed: " .. unhashed)
        kong.log.err("client_hash: " .. client_hash)
        kong.log.err("server_hash: " .. digest_created)

        -- Second check
        if path:sub(-1) == "/" then
          path = path:sub(1, -2)
        else
          path = path .. "/"
        end
        unhashed = trxId .. key .. path .. version
        local digest2 = sha256:new()
        digest2:update(unhashed)
        digest_created = str.to_hex(digest2:final())
        if client_hash ~= digest_created then
          kong.log.err("unhashed: " .. unhashed)
          kong.log.err("client_hash: " .. client_hash)
          kong.log.err("server_hash: " .. digest_created)
          return kong.response.exit(403, {message = "Forbidden"})
        end
      end
    end
  else
    local minVersion = conf.mobile_min_version
    local version = ngx.req.get_headers()["mytelkomsel-mobile-app-version"]

    if version == nil then
      return kong.response.exit(403, {message = "Forbidden"})
    end

    local compared = compareVersion(version, minVersion)
    if compared >= 0 and conf.mobile_enable then
      local key = conf.mobile_hash_key
      local unhashed = trxId .. path .. version .. key
      local digest = sha256:new()
      digest:update(unhashed)
      local digest_created = str.to_hex(digest:final())
      if client_hash ~= digest_created then
        kong.log.err("unhashed: " .. unhashed)
        kong.log.err("client_hash: " .. client_hash)
        kong.log.err("server_hash: " .. digest_created)

        -- Second check
        if path:sub(-1) == "/" then
          path = path:sub(1, -2)
        else
          path = path .. "/"
        end
        unhashed = trxId .. path .. version .. key
        local digest2 = sha256:new()
        digest2:update(unhashed)
        digest_created = str.to_hex(digest2:final())
        if client_hash ~= digest_created then
          kong.log.err("unhashed: " .. unhashed)
          kong.log.err("client_hash: " .. client_hash)
          kong.log.err("server_hash: " .. digest_created)
          return kong.response.exit(403, {message = "Forbidden"})
        end
      end
    end
  end
end

function startswith(text, prefix)
  return text:find(prefix, 1, true) == 1
end

function compareVersion(ver1, ver2)
  local v1 = Split(ver1)
  local v2 = Split(ver2)
  for i = 1,3 do
    local z = compareStr(v1[i], v2[i])
    if (z ~= 0 or i == 3) then
      return z
    end
  end
end

function compareStr(s1, s2)
  if tonumber(s1) < tonumber(s2) then
    return -1
  elseif tonumber(s1) > tonumber(s2) then
    return 1
  else
    return 0        
  end 
end

function Split(s)
  local result = {}
  for match in s:gsub("%f[.]%.%f[^.]", "\0"):gmatch"%Z+" do
      table.insert(result, match)
  end
  return result
end

return plugin

