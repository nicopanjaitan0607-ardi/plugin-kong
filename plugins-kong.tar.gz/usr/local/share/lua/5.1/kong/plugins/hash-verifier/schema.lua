return {
  no_consumer = true,
  fields = {
    skipped_api = {type = "array"},
    path_prefix = {type = "array"},
    continue_on_error = {type = "boolean", default = true},
    mobile_hash_key = {type = "string", default = "1414ta7132ad4t612bs14"},
    mobile_min_version = {type = "string", default = "4.0.0"},
    mobile_enable = {type = "boolean", default = true},
    web_hash_key = {type = "string", default = "UwW2evFs485sPkjX2526JSLv5wGLp3bM"},
    web_enable = {type = "boolean", default = true},
    web_min_version = {type = "string", default = "1.5.4"}
  }
}

