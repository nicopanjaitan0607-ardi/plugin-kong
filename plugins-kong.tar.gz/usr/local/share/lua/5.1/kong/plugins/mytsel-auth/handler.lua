local https = require("ssl.https")
local json = require "cjson"
local req_set_header = ngx.req.set_header
local set_raw_body = kong.service.request.set_raw_body
local read_body = ngx.req.read_body
local get_body = ngx.req.get_body_data

local http = require "resty.http"
local url = require "socket.url"

local plugin = {
  PRIORITY = 1000,
  VERSION = "0.2"
}

function checkEligibility(path, channel, version, config)
  if channel == nil or channel == "WEB" then
    return false
  end

  local chkconfig = splitWithComma(config)
  local api = chkconfig[1]
  local minVersion = chkconfig[2]
  local prefix = chkconfig[3]
  local chk1 = api
  local chk2 = "/" .. api
  local diff = compareVersion(version, minVersion)
  if diff >= 0 and ( (prefix == "true" and (startswith(path, chk1) or startswith(path, chk2))) or (prefix == "false" and (path == chk1 or path ==  chk2)) ) then
    return true
  end

  return false
end

function plugin:access(conf)
  local path = kong.request.get_path()
  local channel = ngx.req.get_headers()["channelid"]
  local version = ngx.req.get_headers()["mytelkomsel-mobile-app-version"]

  if conf.path_prefix ~= nil then
    local path_prefix = conf.path_prefix
    for i = 1, #path_prefix do
      if startswith(path, "/" .. path_prefix[i]) then
        path = path:sub(string.len(path_prefix[i]) + 2)
        break
      end
    end
  end

  path = path:gsub("/services/api/", "")
  path = path:gsub("/api/", "")

  local skipped_api = conf.skipped_api
	if skipped_api ~= nil and path ~= nil then
    for i = 1, #skipped_api do
      if startswith(path, skipped_api[i]) or startswith(path, "/" .. skipped_api[i]) then
        return true
      end
    end
	end

  local dh = 'false'
  local introspect = 'false'

  local dh_list = conf.dh
  if dh_list ~= nil and kong.request.get_method() == "POST" then
    for i = 1, #dh_list do
      if checkEligibility(path, channel, version, dh_list[i]) then
        dh = 'true'
        break
      end
    end
  end

  local introspect_list = conf.introspect
  if introspect_list ~= nil then
    for i = 1, #introspect_list do
      if checkEligibility(path, channel, version, introspect_list[i]) then
        introspect = 'true'
        break
      end
    end
  end

  local reqMethod = "GET"
  local reqbody = ""
  local authPath = ""
  local endpoint = conf.endpoint

  local partner_list = conf.partner
  if partner_list ~= nil then
    for i = 1, #partner_list do
      if startswith(path, partner_list[i]) or startswith(path, "/" ..partner_list[i]) then
        authPath = "/partner/validate"
        reqMethod = "POST"
        read_body()
        reqbody = get_body()
        break
      end
    end
  end

  if dh == 'true' then
    if conf.endpoint_dh ~= nil then
      endpoint = conf.endpoint_dh
    end
    reqMethod = "POST"
    read_body()
    reqbody = get_body()
  end

  local headers = {
      ["content-length"] = #reqbody,
      ["Content-Type"] = "application/x-www-form-urlencoded",
      ["Authorization"] = ngx.req.get_headers()["authorization"],
      ["AccessAuthorization"] = ngx.req.get_headers()["accessauthorization"],
      ["authserver"] = ngx.req.get_headers()["authserver"],
      ["MYTELKOMSEL-MOBILE-APP-VERSION"] = ngx.req.get_headers()["mytelkomsel-mobile-app-version"],
      ["CHANNELID"] = ngx.req.get_headers()["channelid"],
      ["subchannelid"] = ngx.req.get_headers()["subchannelid"],
      ["transactionid"] = ngx.req.get_headers()["transactionid"],
      ["x-forwarded-path"] = ngx.req.get_headers()["x-forwarded-path"],
      ["journeyID"] = ngx.req.get_headers()["journeyID"],
      ["deviceid"] = ngx.req.get_headers()["deviceid"],
      ["web-msisdn"] = ngx.req.get_headers()["web-msisdn"],
      ["osversion"] = ngx.req.get_headers()["osversion"],
      ["Content-Type"] = "application/json",
      ["endpoint"] = path,
      ["dh"] = dh,
      ["introspect"] = introspect
  }

  local code, jsonResp = makeHttpRequest(conf, endpoint .. authPath, reqMethod, headers, reqbody)

  if code == 200 then
    if jsonResp ~= nil and jsonResp ~= "" then
      local luaResp = json.decode(jsonResp)
      if luaResp.msisdn ~= nil and luaResp.msisdn ~= "" then
        req_set_header('X-msisdn', luaResp.msisdn)
      end
      if luaResp.oldUid ~= nil and luaResp.oldUid ~= "" then
        req_set_header('X-oldUid', luaResp.oldUid)
      end
      if luaResp.uuid ~= nil and luaResp.uuid ~= "" then
        req_set_header('X-uuid', luaResp.uuid)
      end
      if dh == 'true' and luaResp.body ~= nil and luaResp.body ~= "" then
        set_raw_body(json.encode(luaResp.body))
      end
    end
  else -- code ~= 200
    if code == 500 or jsonResp == nil or jsonResp == "" then
      kong.log.err(jsonResp);
      return kong.response.exit(500, {message = "Internal Server Error"})
    else
      return kong.response.exit(code, jsonResp)
    end
  end

end

function startswith(text, prefix)
  return text:find(prefix, 1, true) == 1
end

function splitWithComma(str)
  local fields = {}
  for field in str:gmatch('([^,]+)') do
    table.insert(fields, field)
  end
  return fields
end

function compareVersion(ver1, ver2)
  local v1 = Split(ver1)
  local v2 = Split(ver2)
  for i = 1,3 do
    local z = compareStr(v1[i], v2[i])
    if (z ~= 0 or i == 3) then
      return z
    end
  end
end

function compareStr(s1, s2)
  if tonumber(s1) < tonumber(s2) then
    return -1
  elseif tonumber(s1) > tonumber(s2) then
    return 1
  else
    return 0        
  end 
end

function Split(s)
  local result = {}
  for match in s:gsub("%f[.]%.%f[^.]", "\0"):gmatch"%Z+" do
      table.insert(result, match)
  end
  return result
end

function makeHttpRequest(conf, endpoint, method, headers, body)
  local parsed_url = url.parse(endpoint)

  local host = parsed_url.host
  local is_https = parsed_url.scheme == "https"
  local port = parsed_url.port or (is_https and 443 or 80)
  local path = parsed_url.path

  -- Trigger request
  local client = http.new()

  client:set_timeout(conf.timeout)

  local ok, err = client:connect(host, port)
  if not ok then
    return 500, err
  end
  
  if is_https then
    ok, err = client:ssl_handshake()
    if not ok then
      return 500, err
    end
  end

  local res, err = client:request {
    method = method,
    path = path,
    body = body,
    headers = headers,
  }

  if not res then
    return 500, err
  end

  local status = res.status
  local respBody = res:read_body()

  ok, err = client:set_keepalive(conf.keepalive)
  if not ok then
    ngx_log(WARN, "failed moving conn to keepalive pool: ", err)
  end

  return status, respBody

end

return plugin
