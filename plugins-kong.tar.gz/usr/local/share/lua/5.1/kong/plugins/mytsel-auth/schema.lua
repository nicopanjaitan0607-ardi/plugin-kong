return {
  no_consumer = true,
  fields = {
    path_prefix = {type = "array"},
    skipped_api = {type = "array"},
    dh = {type = "array"},
    introspect = {type = "array"},
    timeout = {type = "number", default = 10000},
    keepalive = {type = "number", default = 60000},
    partner = {type = "array"},
    endpoint = {type = "string", required = true},
    endpoint_dh = {type = "string"}
  }
}
