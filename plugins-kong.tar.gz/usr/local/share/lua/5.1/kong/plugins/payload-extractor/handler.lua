local json = require "cjson"
local read_body = ngx.req.read_body
local get_body = ngx.req.get_body_data
local req_set_header = ngx.req.set_header

local plugin = {
  PRIORITY = 900,
  VERSION = "0.1"
}

function plugin:access(conf)
  read_body()
  local reqbody = get_body()
  if reqbody ~= nil and conf.field_name ~= nil then
    local field_list = conf.field_name
    local luaResp = json.decode(reqbody)
	for i = 1, #field_list do
      req_set_header('x-' .. field_list[i], luaResp[field_list[i]])
	end 
  end
end

return plugin
