return {
  no_consumer = true,
  fields = {
    field_name = {type = "array"}
  }
}
