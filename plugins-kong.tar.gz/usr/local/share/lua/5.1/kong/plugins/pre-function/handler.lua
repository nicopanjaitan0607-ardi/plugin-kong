return require("kong.plugins.pre-function._handler")(math.huge)
