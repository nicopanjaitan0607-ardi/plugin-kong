local plugin = {
  PRIORITY = 10,
  VERSION = "0.1"
}

function plugin:header_filter(conf)
  local status = kong.response.get_status()
  local status_code = conf.status_code
  if status_code ~= nil then
    for i = 1, #status_code do
      if status == status_code[i] then
        kong.response.set_status(conf.new_status)
      end
    end
  end
end

return plugin
