return {
  name = "update-response-status",
  fields = {
    { config = {
        type = "record",
        fields = {
          { status_code = {
            type = "array",
            default = { 503 },
            elements = { type = "integer", between = {100, 900} },
            len_min = 1,
            required = true,
          }},
          { new_status = {
            type = "integer",
            default = 500
          }}
        }
      }
    }
  }
}

